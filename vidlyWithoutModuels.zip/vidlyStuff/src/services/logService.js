//import Raven from "raven-js";

function init() {
  //   Raven.config("https://c0a24b9d928e4d5d9f92aca6e5f5605e@sentry.io/1531921", {
  //     release: "1-0-0",
  //     environment: "development-test"
  //   }).install();
}

function log(error) {
  console.error(error);
  // Raven.captureException(error);
}

export default {
  init,
  log
};
